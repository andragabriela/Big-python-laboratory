from _datetime import date ,time

my_date = date(1996, 12, 11)
print(my_date)
today=date.today()
print(today)
time2=time(11, 34)
print(time2)
"""data=datetime.datetime.now()
time.sleep(1)
data2=datetime.datetime.now()
print(data<data2)"""
