import unittest

from problema2lab7.business.servicii import ServiceStudent, servicelaborator, serviceasignare
from problema2lab7.erori.exceptii import RepositoryError
from problema2lab7.infrastructura.repozitorii import Repostudent, Repolaborator, Repoasignare
from problema2lab7.validare.valid import Validatorstudent, validatorlaborator, ValidatorAsignare


class TestCase(unittest.TestCase):
    def setUp(self)->None:
        self.repo = Repostudent()
        self.repolab = Repolaborator()
        self.repoasi = Repoasignare()
        self.validator = Validatorstudent()
        self.validatolab = validatorlaborator()
        self.validatorasi = ValidatorAsignare()
        self.srv = ServiceStudent(self.validator,self.repo)
        self.srvlab = servicelaborator(self.validatolab, self.repolab)
        self.srvasi = serviceasignare(self.repo,self.repolab,self.repoasi)
    def test_adauga_student_srv(self):
        self.assertTrue(self.srv.no_of_student()==0)
        self.srv.adauga_in_lista(2,"Ela",217)
        self.assertTrue(self.srv.no_of_student()==1)
        self.assertRaises(RepositoryError,self.srv.adauga_in_lista,2,"Ela",217)

    def test_adauga_laborator_srv(self):
        self.assertTrue(self.srvlab.no_of_laborator() == 0)
        self.srvlab.adauga_in_lista(1,1,1,"o iteratie",21)
        self.assertTrue(self.srvlab.no_of_laborator() == 1)
        self.assertRaises(RepositoryError, self.srvlab.adauga_in_lista, 1,1,1,"o iteratie",21)

    def test_adauga_asignare_srv(self):
        self.assertTrue(self.srvasi.no_of_asi() == 0)
        self.srvasi.adauga(1,1,2,10)
        self.assertTrue(self.srvasi.no_of_asi() == 1)
        self.assertRaises(RepositoryError, self.srvasi.adauga, 1,1,2,10)

    def test_sterge_lab_srv(self):
        self.srvlab.adauga_in_lista(1, 1, 1, "o iteratie", 21)
        self.assertTrue(self.srvlab.no_of_laborator() == 1)
        self.srvlab.delete_lab(1)
        self.assertTrue(self.srvlab.no_of_laborator() == 0)

    def test_sterge_st_srv(self):
        self.srv.adauga_in_lista(2, "Ela", 217)
        self.assertTrue(self.srv.no_of_student() == 1)
        self.srv.delete_student(2)
        self.assertTrue(self.srv.no_of_student() == 0)







