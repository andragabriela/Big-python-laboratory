from domain.entitati import Student, Laborator, Asignare #, StudentDTO
import random
class ServiceStudent(object):
    def __init__(self, valid_student, repo_student):
        self.__valid_student= valid_student
        self.__repo_student= repo_student
    def no_of_student(self):
        return len(self.__repo_student)
    def adauga_in_lista(self, idstudent, nume, grupa):
        student=Student(idstudent, nume, grupa)
        self.__valid_student.valideaza(student)
        self.__repo_student.adauga_student(student)
    def get_all(self):
        return self.__repo_student.get_all()
    def delete_student(self, id2,i):
        self.__valid_student.valid_id(id2)
        self.__repo_student.deletestudent(id2,i)
    def cauta_student(self, id2):
        self.__valid_student.valid_id(id2)
        return self.__repo_student.cauta_dupa_id(id2)
    def cauta_student_dupa_nume(self, nume):
        return self.__repo_student.cauta_dupa_nume(nume)
    def modifica_student(self, idstudent, nume, grupa,i):
        student= Student(idstudent, nume, grupa)
        self.__valid_student.valideaza(student)
        self.__repo_student.modifica_student(idstudent, nume, grupa, i)
    def random_string_generator(self, size, letters):
        return ''.join(random.choice(letters) for x in range(size))
    def adauga_random_student(self):
        idstudent=random.randint(1, 100)
        litere='abcdefghijklmnopqrstuvwxyz'
        nume=self.random_string_generator(5, litere).capitalize()+' '+self.random_string_generator(5, litere).capitalize()
        grupa=random.randint(3, 100)
        self.adauga_in_lista(idstudent,nume, grupa)
class servicelaborator(object):
    def __init__(self,valid_laborator, repo_laborator):
        self.__valid_laborator= valid_laborator
        self.__repo_laborator= repo_laborator
    def no_of_laborator(self):
        return len(self.__repo_laborator)
    def adauga_in_lista(self, idlaborator, nrlaborator,nrproblema, descriere, deadline):
        laborator=Laborator(idlaborator, nrlaborator,nrproblema, descriere, deadline)
        self.__valid_laborator.valideazalab(laborator)
        self.__repo_laborator.adauga_laborator(laborator)
    def get_all_laborator(self):
        return self.__repo_laborator.get_all()
    def delete_lab(self, id2):
        self.__valid_laborator.valid_id(id2)
        self.__repo_laborator.deletelab(id2)
    def cauta_laborator(self, id2):
        self.__valid_laborator.valid_id(id2)
        return self.__repo_laborator.cauta_dupa_id(id2)
    def modifica_laborator(self, idlaborator, nrlaborator,nrproblema, descriere, deadline):
        laborator= Laborator(idlaborator, nrlaborator,nrproblema, descriere, deadline)
        self.__valid_laborator.valideazaasi(laborator)
        self.__repo_laborator.modifica_laborator(idlaborator, nrlaborator,nrproblema, descriere, deadline)

class serviceasignare(object):
    def __init__(self, repo_student, repo_laborator, repo_asignare):
        self.__repostudent = repo_student
        self.__repolaborator = repo_laborator
        self.__repoasignare = repo_asignare
    def no_of_asi(self):
        return len(self.__repoasignare)
    def get_all(self):
        return self.__repoasignare.get_all()
    def cauta_asignare(self, id2):
        return self.__repoasignare.cauta_dupa_id(id2)
    def adauga(self, idstudent, idlaborator, idasignare, nota):
        asignare= Asignare(idstudent, idlaborator, idasignare, nota)
        self.__repoasignare.adauga(asignare)
    def get_nota_id(self,id2):
        return self.__repoasignare.get_nota_id(id2)
    def get_nume(self):
        return self.__repostudent.get_nume()
    """def get_all(self):
        asignari = self.__repoasignare.get_all()
        asignare_data = {}
        for asignare in asignari:
            student = self.__repostudent.cauta_dupa_id(asignare.idstudent)
            laborator = self.__repolaborator.cauta_dupa_id(asignare.idlaborator)
            new_asignare = Asignare(asignare.get_idasignare(), student, laborator, asignare.get_nota())
            if asignare.idstudent not in asignare_data:
                asignare_data[asignare.idstudent] = []
            asignare_data[asignare.idstudent].append(new_asignare)
        rez = []
        for asign_data in asignare_data:
            nume_st = asignare_data[asign_data][0].student.nume
            studentdto = StudentDTO(nume_st)
            for asignare in asignare_data[asign_data]:
                studentdto.add_asignare(asignare)
            rez.append(studentdto)
        return rez"""
