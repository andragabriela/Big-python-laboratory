import unittest

from problema2lab7.domain.entitati import Student, Asignare, Laborator
from problema2lab7.erori.exceptii import RepositoryError
from problema2lab7.infrastructura.repozitorii import Repostudent, Repolaborator, Repoasignare


class TestCase(unittest.TestCase):
    def setUp(self)->None:
        self.repo=Repostudent()
        self.repolab=Repolaborator()
        self.repoasi=Repoasignare()

    def test_adauga_student_repo(self):
        st1 = Student(2, "Ela", 217)
        self.repo.adauga_student(st1)
        self.assertTrue(self.repo.__len__() == 1)
        self.assertRaises(RepositoryError, self.repo.adauga_student,st1)
    def test_modifica_student(self):
        st1 = Student(2, "Ela", 217)
        self.repo.adauga_student(st1)
        self.repo.modifica_student(2,"Andra",215)
        self.assertTrue(self.repo.cauta_dupa_id(2).get_nume()=="Andra")
    def sterge_student(self):
        id2=2
        st1 = Student(1, "Andra", 217)
        st2 = Student(2, "Gabriela", 217)
        st3 = Student(3, "Ela", 217)
        self.repo.adauga_student(st1)
        self.repo.adauga_student(st2)
        self.repo.adauga_student(st3)
        self.repo.deletestudent(id2)
        self.assertTrue(self.repo.__len__()==2)
    def test_find_student(self):
        st3 = Student(3, "Ela", 217)
        self.repo.adauga_student(st3)
        self.assertTrue(self.repo.cauta_dupa_id(3).get_nume()=="Ela")
    def test_adauga_asi_repo(self):
        idstudent = 1
        idlaborator = 1
        idasignare = 2
        nota = 10
        asignare = Asignare(idstudent, idlaborator, idasignare, nota)
        self.repoasi.adauga(asignare)
        self.assertTrue(self.repoasi.__len__() == 1)
        self.assertRaises(RepositoryError, self.repoasi.adauga,asignare)
    def test_modifica_asi(self):
        idstudent = 1
        idlaborator = 1
        idasignare = 2
        nota = 10
        asignare = Asignare(idstudent, idlaborator, idasignare, nota)
        self.repoasi.adauga(asignare)
        self.repoasi.modifica_asignare(2,9)
        self.assertTrue(self.repoasi.cauta_dupa_id(2).get_nota()==9)
    def test_sterge_asi(self):
        idstudent = 1
        idlaborator = 1
        idasignare = 2
        nota = 10
        asignare = Asignare(idstudent, idlaborator, idasignare, nota)
        self.repoasi.adauga(asignare)
        self.repoasi.deleteasignare(2)
        self.assertTrue(self.repo.__len__()==0)

    def test_adauga_lab_repo(self):
        p=Laborator(1,1,1,"o iteratie",21)
        self.repolab.adauga_laborator(p)
        self.assertTrue(self.repolab.__len__() == 1)
        self.assertRaises(RepositoryError, self.repolab.adauga_laborator,p)
    def test_modifica_lab(self):
        p=Laborator(1,1,1,"o iteratie",21)
        self.repolab.adauga_laborator(p)
        self.repolab.modifica_laborator(1,1,1,"doua iteratii",22)
        self.assertTrue(self.repolab.cauta_dupa_id(1).get_descriere()=="doua iteratii")
    def sterge_lab(self):
        p=Laborator(1,1,1,"o iteratie",21)
        self.repolab.adauga_laborator(p)
        self.repolab.deletelab(1)
        self.assertTrue(self.repo.__len__()==0)
