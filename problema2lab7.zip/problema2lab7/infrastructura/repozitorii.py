from erori.exceptii import RepositoryError
from domain.entitati import *


class Repostudent(object):
    def __init__(self):
        self._student = []

    def __len__(self):
        return len(self._student)

    def adauga_student(self, student):
        for _st in self._student:
            if _st == student:
                raise RepositoryError("id existent!\n")
        self._student.append(student)

    def cauta_dupa_id(self, idstudent):
        """
        cauta student dupa id
        """

        for _st in self._student:
            if _st.get_idstudent() == idstudent:
                return _st
        raise RepositoryError("id inexistent!\n")

    def cauta_dupa_nume(self, nume):
        for _st in self._student:
            if _st.get_nume() == nume:
                return _st

    def get_all(self):
        return self._student[:]

    def deletestudent2(self, id2):
        """
        Complexitate O(n) pt ca ave cazul favorabil diferit de cazul defavorabil
        caz favorabil: id-ul cautat este primul-> teta de 1
        caz defavorabil: id-ul cautat nu exista-> teta de n
        caz mediu: (n+1)/2-> O n
        """
        """sterge studentul de la id-ul dat"""
        i = 0
        while i < len(self._student):
            if self._student[i].get_idstudent() == id2:
                self._student.pop(i)
            else:
                i = i + 1
    def deletestudent(self, id2, i):
        try:
            if self._student[i].get_idstudent()==id2:
                self._student.pop(i)
                return
            self.deletestudent(id2, i+1)
        except IndexError:
            raise RepositoryError("id inexistent")

    def modifica_student2(self, idstudent, nume, grupa):
        """
        modifica numele si grupa studentului cu id-ul dat
        """

        for _st in self.get_all():
            if _st.get_idstudent() == idstudent:
                _st.set_nume(nume)
                _st.set_grupa(grupa)
                break

    def modifica_student(self, idstudent, nume, grupa, i):
        try:
            if self._student[i].get_idstudent()==idstudent:
                self._student[i].set_nume(nume)
                self._student[i].set_grupa(grupa)
                return
            self.modifica_student(idstudent, nume, grupa, i+1)
        except IndexError:
            raise RepositoryError("id inexistent")


class FileRepoStudent(Repostudent):
    def __init__(self, filepath):
        Repostudent.__init__(self)
        self.__filepath = filepath
    def modifica_student(self, idstudent, nume, grupa,i):
        self.__read_all_from_file()
        Repostudent.modifica_student(self, idstudent,nume, grupa,i)
        self.__write_to_file()
    def deletestudent(self, id2, i):
        self.__read_all_from_file()
        Repostudent.deletestudent(self, id2,i)
        self.__write_to_file()

    def adauga(self, student):
        self.__read_all_from_file()
        Repostudent.adauga_student(self, student)
        self.__append_to_file(student)

    def __len__(self):
        self.__read_all_from_file()
        return Repostudent.__len__(self)

    def get_all(self):
        self.__read_all_from_file()
        return Repostudent.get_all(self)

    def cauta_dupa_id(self, idstudent):
        self.__read_all_from_file()
        return Repostudent.cauta_dupa_id(self, idstudent)

    def __read_all_from_file(self):
        with open(self.__filepath, "r") as f:
            self._student = []
            lines = f.readlines()
            for line in lines:
                line = line.strip()
                if len(line) > 0:
                    parts = line.split(',')
                    idstudent = int(parts[0])
                    nume = parts[1]
                    grupa = int(parts[2])
                    student = Student(idstudent, nume, grupa)
                    self._student.append(student)

    def __append_to_file(self, student):
        with open(self.__filepath, "a") as f:
            f.write(f"\n{student.idstudent},{student.nume}")

    def __write_to_file(self):
        with open(self.__filepath, "w") as f:
            for stu in self._student:
                f.write(f"\n{stu.get_idstudent()},{stu.get_nume()},{stu.get_grupa()}")


class Repolaborator(object):
    def __init__(self):
        self._laborator = []

    def __len__(self):
        return len(self._laborator)

    def adauga_laborator(self, laborator):
        for _lab in self._laborator:
            if _lab == laborator:
                raise RepositoryError("id existent!\n")
        self._laborator.append(laborator)

    def cauta_dupa_id(self, idlaborator):
        for _lab in self._laborator:
            if _lab.get_idlab() == idlaborator:
                return _lab
        raise RepositoryError("id inexistent!\n")

    def cauta_laborator_numar(self, nr):
        for _lab in self._laborator:
            if _lab.get_nrlab() == nr:
                return _lab

    def get_all(self):
        return self._laborator

    def deletelab(self, id2):
        i = 0
        while i < len(self._laborator):
            if self._laborator[i].get_idlab() == id2:
                self._laborator.pop(i)
            else:
                i = i + 1

    def modifica_laborator(self, idlaborator, nrlab, nrproblema, descriere, deadline):
        for _lab in self.get_all():
            if _lab.get_idlab() == idlaborator:
                _lab.set_nrlab(nrlab)
                _lab.set_nrproblema(nrproblema)
                _lab.set_descriere(descriere)
                _lab.set_deadline(deadline)
                break


class Filerepolaborator(Repolaborator):
    def __init__(self, filepath):
        Repolaborator.__init__(self)
        self.__filepath = filepath

    def adauga(self, laborator):
        self.__read_all_from_file()
        Repolaborator.adauga_laborator(self, laborator)
        self.__append_to_file(laborator)

    def cauta_dupa_id(self, idlaborator):
        self.__read_all_from_file()
        return Repolaborator.cauta_dupa_id(self, idlaborator)
    def modifica_laborator(self, idlaborator, nrlab, nrproblema, descriere, deadline):
        self.__read_all_from_file()
        Repolaborator.modifica_laborator(self, idlaborator, nrlab, nrproblema, descriere, deadline)
        self.__write_to_file()
    def deletelab(self, id2):
        self.__read_all_from_file()
        Repolaborator.deletelab(self, id2)
        self.__write_to_file()
    def __len__(self):
        self.__read_all_from_file()
        return Repolaborator.__len__(self)

    def get_all(self):
        self.__read_all_from_file()
        return Repolaborator.get_all(self)

    def __read_all_from_file(self):
        with open(self.__filepath, "r") as f:
            self._laborator = []
            lines = f.readlines()
            for line in lines:
                line = line.strip()
                if len(line) > 0:
                    parts = line.split(',')
                    idlaborator = int(parts[0])
                    nrlab = parts[1]
                    nrproblema = parts[2]
                    descriere = parts[3]
                    deadline = parts[4]
                    laborator = Laborator(idlaborator, nrlab, nrproblema, descriere, deadline)
                    self._laborator.append(laborator)

    def __append_to_file(self, laborator):
        with open(self.__filepath, "a") as f:
            f.write(
                f"{laborator.get_idlab()},{laborator.get_nrlab()}, {laborator.get_nrproblema()}, {laborator.get_descriere()},{laborator.get_deadline()} \n")
    def __write_to_file(self):
        with open(self.__filepath, "w") as f:
            for lab in self._laborator:
                f.write(f"\n{lab.get_idlab()},{lab.get_nrlab()},{lab.get_nrproblema()},{lab.get_descriere()},{lab.get_deadline()}")



class Repoasignare(object):
    def __init__(self):
        self._asignare = []

    def get_all(self):
        return self._asignare

    def __len__(self):
        return len(self._asignare)

    def adauga(self, asignare):
        for _asi in self._asignare:
            if _asi == asignare:
                raise RepositoryError("id existent!\n")
        self._asignare.append(asignare)

    def cauta_dupa_id(self, id2):
        for _asi in self._asignare:
            if _asi.get_idasignare() == id2:
                return _asi
        raise RepositoryError("id inexistent!\n")

    def get_nota_id(self, id2):
        for _asi in self._asignare:
            if _asi.get_idasignare() == id2:
                return _asi.get_nota()
    def deleteasignare(self, id2):
        i = 0
        while i < len(self._asignare):
            if self._asignare[i].get_idasignare() == id2:
                self._asignare.pop(i)
            else:
                i = i + 1

    def modifica_asignare(self, idasignare, nota):
        """ modifica nota de la o asignare data"""
        for _asi in self.get_all():
            if _asi.get_idasignare() == idasignare:
                _asi.set_nota(nota)
                break

class Filerepoasignare(Repoasignare):
    def __init__(self, filepath):
        Repoasignare.__init__(self)
        self.__filepath = filepath
    def modifica_asignare(self, idasignare, nota):
        self.__read_from_file()
        Repoasignare.modifica_asignare(self, idasignare, nota)
        self.__write_to_file()

    def deletelab(self, id2):
        self.__read_from_file()
        Repoasignare.deleteasignare(self, id2)
        self.__write_to_file()
    def __len__(self):
        self.__read_from_file()
        return Repoasignare.__len__(self)
    def __read_from_file(self):
        with open(self.__filepath, "r") as f:
            self._asignare = []
            lines = f.readlines()
            for line in lines:
                line = line.strip()
                if len(line) > 0:
                    parts = line.split(',')
                    idasignare = int(parts[0])
                    idstudent = int(parts[1])
                    idlaborator = int(parts[2])
                    nota = int(parts[3])
                    asignare = Asignare(idasignare, idstudent, idlaborator, nota)
                    self._asignare.append(asignare)
    def __append_to_file(self, asignare):
        with open(self.__filepath, "a") as f:
            f.write(f"{asignare.get_idasignare()},{asignare.get_idstudent()}, {asignare.get_idlaborator()}\n")
    def __write_to_file(self):
        with open(self.__filepath, "w") as f:
            for asignare in self._asignare:
                f.write(f"{asignare.get_idasignare()},{asignare.get_idstudent()}, {asignare.get_idlaborator()}\n")

    def get_all(self):
        self.__read_from_file()
        return Repoasignare.get_all(self)
