class Student(object):
    def __init__(self, idstudent, nume, grupa):
        self.__idstudent=idstudent
        self.__nume= nume
        self.__grupa=grupa
    def get_idstudent(self):
        return self.__idstudent
    def get_nume(self):
        return self.__nume
    def get_grupa(self):
        return self.__grupa
    def __eq__(self, other):
        return self.__idstudent==other.__idstudent
    def __str__(self):
        return "["+str(self.__idstudent)+"]"+self.__nume+"->"+str(self.__grupa)
    def set_nume(self, value):
        self.__nume=value
    def set_grupa(self, value):
        self.__grupa= value
class Laborator(object):
    def __init__(self, idlaborator, nrlab,nrproblema,descriere, deadline):
        self.__idlaborator= idlaborator
        self.__nrlab= nrlab
        self.__nrproblema= nrproblema
        self.__descriere=descriere
        self.__deadline= deadline

    def get_idlab(self):
        return self.__idlaborator
    def get_nrlab(self):
        return self.__nrlab
    def get_nrproblema(self):
        return self.__nrproblema
    def get_descriere(self):
        return self.__descriere
    def get_deadline(self):
        return self.__deadline
    def __eq__(self, other):
        return self.__idlaborator==other.__idlaborator
    def __str__(self):
        return str(self.__idlaborator)+"->"+str(self.__nrlab)+"_"+str(self.__nrproblema)+"->"+self.__descriere+" pana la data "+str(self.__deadline)
    def set_nrlab(self, value):
        self.__nr_lab=value
    def set_nrproblema(self, value):
        self.__nrproblema=value
    def set_descriere(self, value):
        self.__descriere=value
    def set_deadline(self, value):
        self.__deadline=value
class Asignare(object):
    def __init__(self, idstudent, idlaborator,idasignare, nota):
        self.__idasignare = idasignare
        self.__idstudent=idstudent
        self.__idlaborator= idlaborator
        self.__nota= nota

    def get_idasignare(self):
        return self.__idasignare

    def get_idstudent(self):
        return self.__idstudent
    def set_idstudent(self, value):
        self.__idstudent = value
    def get_nota(self):
        return self.__nota
    def set_nota(self, value):
        self.__nota=value
    def get_idlaborator(self):
        return self.__idlaborator
    def set_laborator(self, value):
        self.__idlaborator = value

    def __eq__(self, other):
        return self.__idasignare == other.__idasignare

    def __str__(self):
        return str(self.__idasignare)+" studentul cu id-ul "+str(self.__idstudent)+" are laboratorul cu id-ul "+str(self.__idlaborator)+" la care are nota "+str(self.__nota)

class StudentDTO:
    def __init__(self, nume_student, nota):
        self.__nota = nota
        self.__nume_student = nume_student
        self.__list_student = []
    def get_nume(self):
        return self.__nume_student

    def get_nota(self):
        return self.__nota

    def __str__(self):
        return self.__nume_student+" "+str(self.__nota)