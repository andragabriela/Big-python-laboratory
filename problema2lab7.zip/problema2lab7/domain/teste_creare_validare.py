import unittest

from problema2lab7.domain.entitati import Student, Asignare, Laborator
from problema2lab7.erori.exceptii import ValidationError
from problema2lab7.validare.valid import Validatorstudent, validatorlaborator, ValidatorAsignare


class TestCaseStudent(unittest.TestCase):
    def setUp(self)->None:
        self.__validator=Validatorstudent()
        self.__validatolab=validatorlaborator()
        self.__validatorasi=ValidatorAsignare()

    def test_creaza_st(self):
        p=Student(1,'Andra',217)
        self.assertTrue(p.get_idstudent()==1)
        self.assertTrue(p.get_nume()=='Andra')
        self.assertTrue(p.get_grupa()==217)
    def test_valideaza_studen(self):
        p = Student(1, '', 217)
        self.assertRaises(ValidationError,self.__validator.valideaza,p)
    def test_creaza_asi(self):
        idstudent = 1
        idlaborator = 1
        idasignare = 2
        nota = 10
        asignare = Asignare(idstudent, idlaborator, idasignare, nota)
        self.assertTrue(asignare.get_idlaborator()==1)
        self.assertTrue(asignare.get_idasignare()==2)
        self.assertTrue(asignare.get_idstudent()==1)
        self.assertTrue(asignare.get_nota()==10)

    def test_valideaza_asi(self):
        p = Asignare(1, -1,-1, 9)
        self.assertRaises(ValidationError,self.__validatorasi.valideazaasi,p)
    def test_creaza_lab(self):
        p=Laborator(1,1,1,"o iteratie",21)
        self.assertTrue(p.get_idlab()==1)
        self.assertTrue(p.get_deadline()==21)
        self.assertTrue(p.get_nrlab()==1)
        self.assertTrue(p.get_nrproblema()==1)
        self.assertTrue(p.get_descriere()=="o iteratie")

    def test_valideaza_lab(self):
        p=Laborator(1,1,1,"",21)
        self.assertRaises(ValidationError,self.__validatolab.valideazalab,p)
