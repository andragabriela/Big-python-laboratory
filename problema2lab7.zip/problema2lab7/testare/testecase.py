from problema2lab7.domain.entitati import Student, Asignare, Laborator
from problema2lab7.erori.exceptii import ValidationError, RepositoryError
from problema2lab7.validare.valid import Validatorstudent, validatorlaborator
from problema2lab7.infrastructura.repozitorii import Repostudent, Repolaborator
from problema2lab7.business.servicii import ServiceStudent
import unittest
class TesteCase(unittest.TestCase):
    def __test_valideaza_student(self):
        idstudent = 1
        nume = "Pop Maria"
        grup = 215
        student = Student(idstudent, nume, grup)
        valid=Validatorstudent()
        valid.valideaza(student)
        inv_idstudent = -1
        inv_nume = ""
        inv_grup = -215
        inv_id_student = Student(inv_idstudent, nume, grup)
        try:
            valid.valideaza(inv_id_student)
            assert(False)
        except ValidationError as ve:
            assert(str(ve)=="id invalid!\n")
        inv_student = Student(inv_idstudent, inv_nume, inv_grup)
        try:
            valid.valideaza(inv_student)
            assert (False)
        except ValidationError as ve:
            assert (str(ve) == "id invalid!\nnume invalid!\ngrupa invalida!\n")
    def __test_adauga_student_repo(self):
        idstudent = 1
        nume = "Pop Maria"
        grup = 215
        student=Student(idstudent,nume,grup)
        repo= Repostudent()
        assert(len(repo)==0)
        assert(repo.__len__()==0)
        repo.adauga_student(student)
        assert(len(repo)==1)
        student_gasit=repo.cauta_dupa_id(idstudent)
        assert(student_gasit==student)
        assert(student.get_nume()==student_gasit.get_nume())
        assert(student.get_grupa()==student_gasit.get_grupa())
        id_inexistent=2
        try:
            student_gasit=repo.cauta_dupa_id(id_inexistent)
            assert(False)
        except RepositoryError as re:
            assert(str(re)=="id inexistent!\n")
        inv_nume = ""
        inv_grup = -215
        inv_student = Student(idstudent,inv_nume, inv_grup)
        try:
            student_gasit=repo.adauga_student(inv_student)
            assert (False)
        except RepositoryError as re:
            assert (str(re) == "id existent!\n")
    def __adauga_student_service(self):
        idstudent = 1
        nume = "Pop Maria"
        grup = 215
        repo= Repostudent()
        valid= Validatorstudent()
        srv= ServiceStudent(valid, repo)
        assert(srv.no_of_student()==0)
        srv.adauga_in_lista(idstudent, nume, grup)
        assert (srv.no_of_student() == 1)
        try:
            srv.adauga_in_lista(idstudent, nume, grup)
            assert(False)
        except RepositoryError as re:
            assert(str(re)=="id existent!\n")
        inv_idstudent = -1
        inv_nume = ""
        inv_grup = -215
        try:
            srv.adauga_in_lista(inv_idstudent, inv_nume, inv_grup)
            assert(False)
        except ValidationError as ve:
            assert (str(ve) == "id invalid!\nnume invalid!\ngrupa invalida!\n")
    def __test_creeaza_asignare(self):
        idstudent = 1
        idlaborator = 1
        idasignare = 2
        nota = 10
        asignare = Asignare(idstudent, idlaborator, idasignare, nota)
        assert (asignare.get_idlaborator() == idlaborator)
        assert (asignare.get_idasignare() == idasignare)
        assert (asignare.get_idstudent() == idstudent)
        alt_idstudent = 2
        alt_idlaborator = 4
        alta_nota=3
        alta_asignare = Asignare(alt_idstudent, alt_idlaborator, idasignare, alta_nota)
        assert (asignare == alta_asignare)
        assert (asignare.__eq__(alta_asignare))
    def __test_creeaza_laborator(self):
        idlaborator=1
        nrlab=1
        nrproblema=2
        descriere="se fac doua iteratii"
        deadline=12
        laborator=Laborator(idlaborator, nrlab,nrproblema,descriere, deadline)
        assert(laborator.get_idlab()==idlaborator)
        assert(laborator.get_nrlab()==nrlab)
        assert(laborator.get_nrproblema()==nrproblema)
        assert(laborator.get_descriere()==descriere)
        assert(laborator.get_deadline()==deadline)
        alt_nrlab = 2
        alt_nrproblema = 4
        alta_descriere = "se fac cinci iteratii"
        alt_deadline = 13
        alt_laborator=Laborator(idlaborator,alt_nrlab,alt_nrproblema, alta_descriere,alt_deadline)
        assert(laborator.__eq__(alt_laborator))
    def __test_valideaza_laborator(self):
        idlaborator = 1
        nrlab = 1
        nrproblema = 2
        descriere = "se fac doua iteratii"
        deadline = 12
        laborator = Laborator(idlaborator, nrlab, nrproblema, descriere, deadline)
        valid=validatorlaborator()
        valid.valideazalab(laborator)
        inv_idlaborator = -1
        inv_nrlab = -1
        inv_nrproblema = -2
        inv_descriere = ""
        inv_deadline = -12
        inv_laborator = Laborator(inv_idlaborator,inv_nrlab, inv_nrproblema, inv_descriere, inv_deadline)
        try:
            valid.valideazalab(inv_laborator)
        except ValidationError as ve:
            assert (str(ve)=="id invalid!\nnumar laborator invalid!\nnumar problema invalid!\ndescriere invalida!\ndeadline invalid!\n")
    def __test_adauga_laborator_repo(self):
        idlaborator = 1
        nrlab = 1
        nrproblema = 2
        descriere = "se fac doua iteratii"
        deadline = 12
        laborator= Laborator(idlaborator, nrlab, nrproblema, descriere, deadline)
        repo=Repolaborator()
        assert (len(repo) == 0)
        assert (repo.__len__() == 0)
        repo.adauga_laborator(laborator)
        assert (len(repo) == 1)
        laborator_gasit = repo.cauta_dupa_id(idlaborator)
        assert (laborator_gasit == laborator)
        assert (laborator.get_nrlab() == laborator_gasit.get_nrlab())
        assert (laborator.get_nrproblema() == laborator_gasit.get_nrproblema())
        assert(laborator.get_descriere()==laborator_gasit.get_descriere())
        assert(laborator.get_deadline()==laborator_gasit.get_deadline())
        id_inexistent = 2
        try:
            laborator_gasit = repo.cauta_dupa_id(id_inexistent)
            assert (False)
        except RepositoryError as re:
            assert (str(re) == "id inexistent!\n")
        nrlab_rau = -1
        nrproblema_rau = -2
        descriere_rea = ""
        deadline_rau = -12
        inv_laborator = Laborator(idlaborator, nrlab_rau, nrproblema_rau, descriere_rea, deadline_rau)
        try:
            laborator_gasit = repo.adauga_laborator(inv_laborator)
            assert (False)
        except RepositoryError as re:
            assert (str(re) == "id existent!\n")
    def __test_delete_student(self):
        student= Student(1, "Andra", 217)
        repo= Repostudent()
        repo.adauga_student(student)
        student2 = Student(2, "Gabriela", 227)
        repo.adauga_student(student2)
        repo.deletestudent(2)
        assert (len(repo)==1)
    def __test_delete_laborator(self):
        laborator=Laborator(1,1,2,"o iteratie",12)
        repo= Repolaborator()
        repo.adauga_laborator(laborator)
        laborator2 = Laborator(2,3,4,"doua iteratii",15)
        repo.adauga_laborator(laborator2)
        repo.deletelab(2)
        assert (len(repo)==1)
    def __test_modifica_student(self):
        idstudent = 1
        nume = "Andra"
        grup = 217
        student = Student(idstudent, nume, grup)
        repo= Repostudent()
        repo.adauga_student(student)
        student2=Student(2,"Gabriela",215)
        repo.adauga_student(student2)
        repo.modifica_student(1,"Elisabeta", 214)
        for _st in repo.get_all():
            if(_st.get_idstudent()==1):
                assert(_st.get_nume()=="Elisabeta")
                assert(_st.get_grupa()==214)
                break
    def __test_modifica_laborator(self):
        laborator=Laborator(1,1,2,"o iteratie",12)
        repo = Repolaborator()
        repo.adauga_laborator(laborator)
        repo.modifica_laborator(1,28,9, "doua iteratii", 2)
        for _lab in repo.get_all():
            if (_lab.get_idlab() == 1):
                #assert (_lab.get_nrlab() == 28)
                assert (_lab.get_nrproblema() == 9)
                assert (_lab.get_deadline() == 2)
                assert (_lab.get_descriere() == "doua iteratii")
                break


    def run_all_teste(self):
        print("start teste")

        #self.__test_valideaza_student()
        #self.__test_adauga_student_repo()
        #self.__adauga_student_service()
        #self.__test_creeaza_laborator()
        #self.__test_valideaza_laborator()
        #self.__test_adauga_laborator_repo()
        #self.__test_delete_student()
        #self.__test_modifica_student()
        #self.__test_creeaza_asignare()
        #self.__test_modifica_laborator()
        #self.__test_modifica_laborator()
        print("finish teste")

