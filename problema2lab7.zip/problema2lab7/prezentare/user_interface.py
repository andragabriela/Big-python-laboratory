from erori.exceptii import ValidationError, RepositoryError
import turtle
class Consola(object):
    def __init__(self, srv_student, srv_laborator, srv_asignare, rapoarte):
        self.__srv_asignare = srv_asignare
        self.__srv_student= srv_student
        self.__srv_laborator = srv_laborator
        self.__rapoarte=rapoarte
    def __ui_adauga_student(self):
        try:
            idstudent=int(input("id student: "))
        except ValueError:
            print("id numeric invalid!")
            return
        nume=input("nume student: ")
        try:
            grupa=int(input("grupa studentului: "))
        except ValueError:
            print("grupa numeirca invalida!")
            return
        self.__srv_student.adauga_in_lista(idstudent, nume, grupa)
        print("student adaugat cu succes!")
    def __ui_adauga_laborator(self):
        try:
            idlaborator=int(input("id laborator: "))
        except ValueError:
            print("id numeric invalid!")
            return
        try:
            nrlaborator = int(input("nr laborator: "))
        except ValueError:
            print("nr laborator numeric invalid!")
            return
        try:
            nrproblema=int(input("nr problema: "))
        except ValueError:
            print("nr problema numeric invalid!")
            return
        descriere=input("descriere: ")
        try:
            deadline=int(input("deadline: "))
        except ValueError:
            print("deadline invalid!")
            return
        self.__srv_laborator.adauga_in_lista(idlaborator, nrlaborator,nrproblema, descriere, deadline)
        print("laborator adaugat cu succes!")
    def __ui_adauga_asignare(self):
        try:
            idstudent = int(input("id student: "))
        except ValueError:
            print("id numeric invalid!")
            return
        try:
            idlaborator = int(input("id laborator: "))
        except ValueError:
            print("id numeric invalid!")
            return
        try:
            idasignare = int(input("id asignare: "))
        except ValueError:
            print("id numeric invalid!")
            return
        try:
            nota=int(input("nota este: "))
        except ValueError:
            print("valoare invalida!")
            return
        ok=True
        try:
            self.__srv_student.cauta_student(idstudent)
        except RepositoryError as re:
            ok= False
            print(re)
        ok2 = True
        try:
            self.__srv_laborator.cauta_laborator(idlaborator)
        except RepositoryError as re:
            ok2 = False
            print(re)
        if ok and ok2:
            try:
                self.__srv_asignare.adauga(idstudent, idlaborator, idasignare, nota)
            except RepositoryError as re:
                print(re)
    def __afiseaza_student(self):
        no_of_student=self.__srv_student.get_all()
        if len(no_of_student)==0:
            print("nu avem studenti!")
            return
        for student in no_of_student:
            print(student)
    def __afiseaza_laborator(self):
        no_of_laborator = self.__srv_laborator.no_of_laborator()
        if no_of_laborator == 0:
            print("nu avem laboratoare!")
        for laborator in self.__srv_laborator.get_all_laborator():
            print(laborator)
    def __afiseaza_asignare(self):
        asignare=self.__srv_asignare.get_all()
        if len(asignare)==0:
            print("nu avem asignari!")
            return
        for asi in asignare:
                print(asi)
    def __afiseaza_rapoarte(self):
        id2=int(input("id "))
        try:
            self.__srv_student.cauta_student(id2)
        except RepositoryError as re:
            print(re)
            return
        for st in self.__rapoarte.sort_by_name(id2):
            print(st)
    def __afiseaza_rapoarte2(self):
        for st in self.__rapoarte.st_nota_sub_cinci():
            print(st)
    def __delete(self):
        id2 = int(input("id student de sters: "))
        self.__srv_student.delete_student(id2,0)
    def __delete_lab(self):
        id2 = int(input("id laborator de sters: "))
        self.__srv_laborator.delete_lab(id2)
    def __cauta_student(self):
        try:
            id2 = int(input("id student cautat: "))
        except ValueError:
            print("Id invalid!")
            return
        try:
            print(self.__srv_student.cauta_laborator(id2))
        except ValidationError as ve:
            print("validation error: "+str(ve))
    def __cauta_laborator(self):
        try:
            id2=int(input("id lab cautat: "))
        except ValueError:
            print("id invalid!")
            return
        try:
            print(self.__srv_laborator.cauta_laborator(id2))
        except ValidationError as ve:
            print("validation error "+ str(ve))
    def __ui_modifica_student(self):
        try:
            idstudent=int(input("id student: "))
        except ValueError:
            print("id numeric invalid!")
            return
        nume=input("nume student: ")
        try:
            grupa=int(input("grupa studentului: "))
        except ValueError:
            print("grupa numeirca invalida!")
            return
        self.__srv_student.modifica_student(idstudent, nume, grupa, 0)
    def __ui_modifica_laborator(self):
        try:
            idlaborator = int(input("id laborator: "))
        except ValueError:
            print("id numeric invalid!")
            return
        try:
            nrlaborator = int(input("nr laborator: "))
        except ValueError:
            print("nr laborator numeric invalid!")
            return
        try:
            nrproblema = int(input("nr problema: "))
        except ValueError:
            print("nr problema numeric invalid!")
            return
        descriere = input("descriere: ")
        try:
            deadline = int(input("deadline: "))
        except ValueError:
            print("deadline invalid!")
        self.__srv_laborator.modifica_laborator(idlaborator, nrlaborator,nrproblema, descriere, deadline)
    def __ui_random(self):
        try:
            self.__srv_student.adauga_random_student()
        except ValidationError as ve:
            print(ve)
        except RepositoryError as re:
            print(re)

    def run(self):
        print("""
                    add_student
                    add_laborator
                    add_asignare
                    print: pt studenti
                    print_laborator
                    print_asignare
                    delete student
                    delete laborator
                    cauta laborator
                    cauta student: dupa id
                    """)
        while True:

            cmd=input(">>>")
            if cmd=="":
                continue
            if cmd=="exit":
                return
            if cmd=="add_student":
                try:
                    self.__ui_adauga_student()
                except ValidationError as ve:
                    print("validation error\n"+str(ve))
                except RepositoryError as re:
                    print("Repository Error\n"+str(re))
            elif cmd=="print":
                self.__afiseaza_student()
            elif cmd=="add_asignare":
                try:
                    self.__ui_adauga_asignare()
                except ValidationError as ve:
                    print(ve)
            elif cmd=="add_laborator":
                try:
                    self.__ui_adauga_laborator()
                except ValidationError as ve:
                    print("validation error\n"+str(ve))
                except RepositoryError as re:
                    print("Repository Error\n"+str(re))
            elif cmd=="print_laborator":
                self.__afiseaza_laborator()
            elif cmd=="print_asignare":
                self.__afiseaza_asignare()
            elif cmd=="print_rap1":
                self.__afiseaza_rapoarte()
            elif cmd=="delete student":
                self.__delete()
            elif cmd == "delete laborator":
                self.__delete_lab()
            elif cmd=="cauta student":
                self.__cauta_student()
            elif cmd=="cauta laborator":
                self.__cauta_laborator()
            elif cmd=="modifica student":
                self.__ui_modifica_student()
            elif cmd == "modifica laborator":
                try:
                    self.__ui_modifica_laborator()
                except ValidationError as ve:
                    print("validation error\n")
            elif cmd=="adauga random":
                self.__ui_random()
            elif cmd=="rapoarte_alfabetic":
                self.__ui_rapoarte()
            elif cmd=="note sub 5":
                self.__ui_sub_cinci()
            elif cmd=="afiseaza_rap2":
                self.__afiseaza_rapoarte2()
            elif cmd=="max_st":
                self.__ui_max_st()
            elif cmd=="print_rap3":
                self.__print_max_st()
            elif cmd=="undo":
                self.__ui_undo()
            else:
                print("comanda invalida!\n")

    def __ui_rapoarte(self):
        try:
            id2=int(input("id laborator: "))
        except ValueError as ve:
            print(ve)
        l= self.__rapoarte.raport_student_nota(id2)
        for r in l:
            print(r)
    def __ui_sub_cinci(self):
        l=self.__rapoarte.st_nota_sub_cinci()
        for n in l:
            print(n)

    def __ui_max_st(self):
        self.__rapoarte.lab_st_max()
    def __print_max_st(self):
        for lab in self.__rapoarte.lab_st_max():
            print(lab)

    def __ui_undo(self):
        turtle.undo()