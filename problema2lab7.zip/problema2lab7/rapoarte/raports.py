from domain.entitati import StudentDTO


class Raport:
    def __init__(self,srv_student, srv_laborator, srv_asignare):
        self.__srv_student = srv_student
        self.__srv_laborator=srv_laborator
        self.__srv_asignare=srv_asignare
    def list_asignare(self):
        return self.__srv_asignare.get_all()
    def raport_student_nota(self, idlab):
        student_nota={}
        for asi in self.list_asignare():
            if asi.get_idlaborator()==idlab:
                st= self.__srv_student.cauta_student(asi.get_idstudent())
                nota = asi.get_nota()
                student_nota[st.get_idstudent()]=[st.get_nume(), nota]
        list=[]
        for stud_id in student_nota:
            st_nota=StudentDTO(student_nota[stud_id][0],student_nota[stud_id][1])
            list.append(st_nota)
        list=gnomeSort(list,len(list)-1, key=lambda x: x.get_nume())
        quickSortRec(list,0,len(list)-1, key=lambda x: x.get_nota())
        return list


    def find_student_laborator2(self):
        list_student=[]
        for asi in self.list_asignare():
            st= self.__srv_student.cauta_student(asi.get_idstudent())
            list_student.append(st)
        return list_student
    def st_nota_sub_cinci(self):
        list = self.find_student_laborator2()
        list2={}
        for st in list:
            if st.get_nota() < 5:
                student=StudentDTO(st.get_nume(), st.get_nota())
                list2[st.get_nota()]=student
        return list2

def partition(l,left,right, key, cmp=lambda x,y:x>=y):
    pivot = l[left]
    i = left
    j = right
    while i!=j:
        #while key(l[j])>=key(pivot) and i<j:
        while cmp(l[j],l[i]) and i<j:
             j = j-1
        l[i] = l[j]
        while key(l[i])<=key(pivot) and i<j:
             i = i+1
        l[j] = l[i]
    l[i] = pivot
    return i

def quickSortRec(l, left, right, key):
    # partition the list
    pos = partition(l, left, right,key)
    # order the left part
    if left < pos - 1:
        quickSortRec(l, left, pos - 1,key)
        # order the right part
        if pos + 1 < right:
            quickSortRec(l, pos + 1, right,key)


def gnomeSort(arr, n, key, cmp=lambda x,y:x>=y):
    index = 0
    while index < n:
        if index == 0:
            index = index + 1
        #if key(arr[index]) >= key(arr[index - 1]):
        if cmp(arr[index],arr[index-1]):
            index = index + 1
        else:
            arr[index], arr[index - 1] = arr[index - 1], arr[index]
            index = index - 1

    return arr

