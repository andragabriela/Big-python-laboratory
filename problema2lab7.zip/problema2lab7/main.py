from prezentare.user_interface import Consola
from business.servicii import ServiceStudent, servicelaborator, serviceasignare
from infrastructura.repozitorii import FileRepoStudent, Filerepolaborator, Filerepoasignare
from validare.valid import Validatorstudent, validatorlaborator
from rapoarte.raports import Raport
if __name__=='__main__':
    valid_student = Validatorstudent()

    valid_laborator = validatorlaborator()

    repo_student = FileRepoStudent("student.txt")
    repo_laborator = Filerepolaborator("laborator.txt")
    repo_asignare= Filerepoasignare("asignare.txt")

    srv_student= ServiceStudent(valid_student, repo_student)
    srv_laborator=servicelaborator(valid_laborator,repo_laborator)
    srv_asignare= serviceasignare(repo_student,repo_laborator, repo_asignare)


    rapoarte=Raport(srv_student, srv_laborator, srv_asignare)
    ui=Consola(srv_student, srv_laborator, srv_asignare, rapoarte)
    ui.run()
