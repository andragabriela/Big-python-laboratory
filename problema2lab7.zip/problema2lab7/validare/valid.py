from erori.exceptii import ValidationError

class Validatorstudent(object):
    def valideaza(self, student):
        err=""
        if student.get_idstudent()<0:
            err+="id invalid!\n"
        if student.get_nume()=="":
            err+="nume invalid!\n"
        if student.get_grupa()<0:
            err+="grupa invalida!\n"
        if len(err)>0:
             raise ValidationError(err)
    def valid_id(self, id2):
        err=""
        if id2<0:
            err+="id invalid"
            raise ValidationError(err)
class validatorlaborator(object):
    def valideazalab(self, laborator):
        errori = ""
        if laborator.get_idlab()<0:
            errori+= "id invalid!\n"
        if laborator.get_nrlab()<0:
            errori+= "numar laborator invalid!\n"
        if laborator.get_nrproblema()<0:
            errori+= "numar problema invalid!\n"
        if laborator.get_descriere() == "":
            errori+= "descriere invalida!\n"
        if laborator.get_deadline()< 0 and laborator.get_deadline()>31:
            errori+="deadline invalid!\n"
        if len(errori) > 0:
            raise ValidationError(errori)
    def valid_id(self, id2):
        err=""
        if id2<0:
            err+="id invalid"
        if len(err) > 0:
            raise ValidationError(err)

class ValidatorAsignare(object):
    def valideazaasi(self, asignare):
        errori = ""
        if asignare.get_idasignare()<0:
            errori+= "id invalid!\n"
        if asignare.get_idstudent()<0:
            errori+= "id student invalid!\n"
        if asignare.get_idlaborator()<0:
            errori+= "id laorator invalid!\n"
        if len(errori) > 0:
            raise ValidationError(errori)